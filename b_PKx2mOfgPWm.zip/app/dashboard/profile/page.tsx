"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Upload, Save } from "lucide-react";
import { useLanguage } from "@/lib/language-context";

export default function ProfilePage() {
  const { t } = useLanguage();
  const [isEditing, setIsEditing] = useState(false);
  const [profile, setProfile] = useState({
    name: t("Ahmed Mohammed", "أحمد محمد"),
    email: "ahmed@example.com",
    major: t("Computer Science", "علوم الحاسب"),
    university: t("King Saud University", "جامعة الملك سعود"),
    careerGoal: t("AI/ML Engineer", "مهندس ذكاء اصطناعي"),
    skills: "Python, SQL, React, JavaScript, Data Analysis, Git",
  });

  const [notifications, setNotifications] = useState({
    email: true,
    courses: true,
    progress: false,
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div />
        <Button variant={isEditing ? "default" : "outline"} onClick={() => setIsEditing(!isEditing)}>
          {isEditing ? (
            <>
              <Save className="me-2 h-4 w-4" />
              {t("Save Changes", "حفظ التغييرات")}
            </>
          ) : (
            t("Edit Profile", "تعديل الملف")
          )}
        </Button>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        {/* Profile Info */}
        <Card className="border-border lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">{t("Personal Information", "المعلومات الشخصية")}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary text-xl font-bold text-primary-foreground">
                {profile.name.charAt(0)}
              </div>
              {isEditing && (
                <Button variant="outline" size="sm">
                  <Upload className="me-2 h-4 w-4" />
                  {t("Change Photo", "تغيير الصورة")}
                </Button>
              )}
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="name">{t("Name", "الاسم")}</Label>
                <Input id="name" value={profile.name} onChange={(e) => setProfile({ ...profile, name: e.target.value })} disabled={!isEditing} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">{t("Email", "البريد الإلكتروني")}</Label>
                <Input id="email" type="email" value={profile.email} onChange={(e) => setProfile({ ...profile, email: e.target.value })} disabled={!isEditing} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="major">{t("Major", "التخصص")}</Label>
                <Input id="major" value={profile.major} onChange={(e) => setProfile({ ...profile, major: e.target.value })} disabled={!isEditing} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="university">{t("University", "الجامعة")}</Label>
                <Input id="university" value={profile.university} onChange={(e) => setProfile({ ...profile, university: e.target.value })} disabled={!isEditing} />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="careerGoal">{t("Career Goal", "الهدف المهني")}</Label>
                <Input id="careerGoal" value={profile.careerGoal} onChange={(e) => setProfile({ ...profile, careerGoal: e.target.value })} disabled={!isEditing} />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-base">{t("Quick Stats", "إحصائيات سريعة")}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="rounded-lg bg-muted p-3">
              <p className="text-sm text-muted-foreground">{t("Career Readiness", "جاهزية المسار")}</p>
              <p className="text-2xl font-bold text-primary">78%</p>
            </div>
            <div className="rounded-lg bg-muted p-3">
              <p className="text-sm text-muted-foreground">{t("Skills", "المهارات")}</p>
              <p className="text-2xl font-bold">12</p>
            </div>
            <div className="rounded-lg bg-muted p-3">
              <p className="text-sm text-muted-foreground">{t("Courses Completed", "الدورات المكتملة")}</p>
              <p className="text-2xl font-bold">5</p>
            </div>
            <div className="rounded-lg bg-muted p-3">
              <p className="text-sm text-muted-foreground">{t("Learning Streak", "سلسلة التعلم")}</p>
              <p className="text-2xl font-bold">{t("7 days", "7 أيام")}</p>
            </div>
          </CardContent>
        </Card>

        {/* Skills */}
        <Card className="border-border lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">{t("Skills", "المهارات")}</CardTitle>
          </CardHeader>
          <CardContent>
            {isEditing ? (
              <Textarea
                value={profile.skills}
                onChange={(e) => setProfile({ ...profile, skills: e.target.value })}
                placeholder={t("Enter skills separated by commas", "أدخل المهارات مفصولة بفواصل")}
                rows={3}
              />
            ) : (
              <div className="flex flex-wrap gap-2">
                {profile.skills.split(",").map((skill) => (
                  <span key={skill.trim()} className="rounded-md border border-border bg-muted/50 px-3 py-1.5 text-sm">
                    {skill.trim()}
                  </span>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-base">{t("Notifications", "الإشعارات")}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">{t("Email Notifications", "إشعارات البريد")}</p>
                <p className="text-xs text-muted-foreground">{t("Receive updates via email", "استلم التحديثات عبر البريد")}</p>
              </div>
              <Switch checked={notifications.email} onCheckedChange={(checked) => setNotifications({ ...notifications, email: checked })} />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">{t("New Courses", "دورات جديدة")}</p>
                <p className="text-xs text-muted-foreground">{t("Notify about new courses", "إشعار بالدورات الجديدة")}</p>
              </div>
              <Switch checked={notifications.courses} onCheckedChange={(checked) => setNotifications({ ...notifications, courses: checked })} />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">{t("Weekly Progress", "التقدم الأسبوعي")}</p>
                <p className="text-xs text-muted-foreground">{t("Weekly progress summary", "ملخص التقدم الأسبوعي")}</p>
              </div>
              <Switch checked={notifications.progress} onCheckedChange={(checked) => setNotifications({ ...notifications, progress: checked })} />
            </div>
          </CardContent>
        </Card>

        {/* CV Upload */}
        <Card className="border-border lg:col-span-3">
          <CardHeader>
            <CardTitle className="text-base">{t("CV / Resume", "السيرة الذاتية")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between rounded-lg border border-dashed border-border p-6">
              <div>
                <p className="font-medium">ahmed_cv_2024.pdf</p>
                <p className="text-sm text-muted-foreground">{t("Uploaded on March 15, 2024", "تم الرفع في 15 مارس 2024")}</p>
              </div>
              <Button variant="outline">
                <Upload className="me-2 h-4 w-4" />
                {t("Upload New CV", "رفع سيرة ذاتية جديدة")}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
