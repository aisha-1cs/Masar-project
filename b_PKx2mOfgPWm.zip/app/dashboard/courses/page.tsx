"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Clock, ExternalLink, Search } from "lucide-react";
import { useLanguage } from "@/lib/language-context";

export default function CoursesPage() {
  const { t, isRTL } = useLanguage();
  const [searchQuery, setSearchQuery] = useState("");
  const [skillFilter, setSkillFilter] = useState("all");
  const [levelFilter, setLevelFilter] = useState("all");
  const [providerFilter, setProviderFilter] = useState("all");

  const courses = [
    { id: 1, title: t("Machine Learning Fundamentals", "أساسيات تعلم الآلة"), provider: "SDA", duration: t("8 weeks", "8 أسابيع"), level: "Intermediate", skill: "Machine Learning" },
    { id: 2, title: t("Docker for Developers", "دوكر للمطورين"), provider: "Tuwaiq", duration: t("4 weeks", "4 أسابيع"), level: "Beginner", skill: "Docker" },
    { id: 3, title: t("AWS Cloud Practitioner", "ممارس AWS السحابي"), provider: "SDA", duration: t("6 weeks", "6 أسابيع"), level: "Beginner", skill: "AWS" },
    { id: 4, title: t("TensorFlow Deep Learning", "التعلم العميق بتنسرفلو"), provider: "Tuwaiq", duration: t("10 weeks", "10 أسابيع"), level: "Advanced", skill: "TensorFlow" },
    { id: 5, title: t("Kubernetes Essentials", "أساسيات كوبرنيتس"), provider: "SDA", duration: t("5 weeks", "5 أسابيع"), level: "Intermediate", skill: "Kubernetes" },
    { id: 6, title: t("Python for Data Science", "بايثون لعلم البيانات"), provider: "Tuwaiq", duration: t("6 weeks", "6 أسابيع"), level: "Beginner", skill: "Python" },
  ];

  const filteredCourses = courses.filter((course) => {
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSkill = skillFilter === "all" || course.skill === skillFilter;
    const matchesLevel = levelFilter === "all" || course.level === levelFilter;
    const matchesProvider = providerFilter === "all" || course.provider === providerFilter;
    return matchesSearch && matchesSkill && matchesLevel && matchesProvider;
  });

  const skills = [...new Set(courses.map((c) => c.skill))];
  const levels = [...new Set(courses.map((c) => c.level))];
  const providers = [...new Set(courses.map((c) => c.provider))];

  return (
    <div className="space-y-6">
      {/* Filters */}
      <Card className="border-border">
        <CardContent className="pt-6">
          <div className="flex flex-col gap-4 sm:flex-row">
            <div className="relative flex-1">
              <Search className={`absolute top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground ${isRTL ? "right-3" : "left-3"}`} />
              <Input
                placeholder={t("Search courses", "البحث عن دورات")}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={isRTL ? "pr-9" : "pl-9"}
              />
            </div>
            <Select value={skillFilter} onValueChange={setSkillFilter}>
              <SelectTrigger className="w-full sm:w-[150px]">
                <SelectValue placeholder={t("Skill", "المهارة")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("All Skills", "جميع المهارات")}</SelectItem>
                {skills.map((skill) => (
                  <SelectItem key={skill} value={skill}>{skill}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={levelFilter} onValueChange={setLevelFilter}>
              <SelectTrigger className="w-full sm:w-[150px]">
                <SelectValue placeholder={t("Level", "المستوى")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("All Levels", "جميع المستويات")}</SelectItem>
                {levels.map((level) => (
                  <SelectItem key={level} value={level}>{level}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={providerFilter} onValueChange={setProviderFilter}>
              <SelectTrigger className="w-full sm:w-[150px]">
                <SelectValue placeholder={t("Provider", "المزود")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("All Providers", "جميع المزودين")}</SelectItem>
                {providers.map((provider) => (
                  <SelectItem key={provider} value={provider}>{provider}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Courses Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filteredCourses.map((course) => (
          <Card key={course.id} className="border-border">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <span className={`rounded px-2 py-1 text-xs font-medium ${course.provider === "SDA" ? "bg-primary/10 text-primary" : "bg-accent/20 text-accent-foreground"}`}>
                  {course.provider}
                </span>
                <span className={`rounded px-2 py-1 text-xs ${course.level === "Beginner" ? "bg-green-100 text-green-700" : course.level === "Intermediate" ? "bg-yellow-100 text-yellow-700" : "bg-red-100 text-red-700"}`}>
                  {course.level}
                </span>
              </div>
              <CardTitle className="mt-2 text-base">{course.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4 flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  {course.duration}
                </span>
                <span className="rounded bg-muted px-2 py-0.5">{course.skill}</span>
              </div>
              <Button className="w-full">
                <ExternalLink className="me-2 h-4 w-4" />
                {t("View Course", "عرض الدورة")}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredCourses.length === 0 && (
        <Card className="border-border">
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground">{t("No courses found matching your filters.", "لا توجد دورات مطابقة للفلاتر المحددة")}</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
