"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/lib/language-context";

export default function SkillGapPage() {
  const { t } = useLanguage();

  const requiredSkills = [
    { name: t("Machine Learning", "تعلم الآلة"), level: t("Advanced", "متقدم"), current: 30, required: 80, priority: "high" },
    { name: t("Docker", "دوكر"), level: t("Intermediate", "متوسط"), current: 40, required: 70, priority: "medium" },
    { name: t("AWS", "خدمات أمازون"), level: t("Intermediate", "متوسط"), current: 25, required: 60, priority: "low" },
    { name: t("Kubernetes", "كوبرنيتس"), level: t("Basic", "أساسي"), current: 10, required: 50, priority: "medium" },
    { name: t("TensorFlow", "تنسرفلو"), level: t("Intermediate", "متوسط"), current: 20, required: 65, priority: "high" },
  ];

  const currentSkills = [
    { name: t("Python", "بايثون"), level: 85 },
    { name: t("SQL", "قواعد البيانات"), level: 75 },
    { name: t("React", "ريأكت"), level: 70 },
    { name: t("JavaScript", "جافاسكريبت"), level: 80 },
    { name: t("Data Analysis", "تحليل البيانات"), level: 65 },
    { name: t("Git", "جيت"), level: 70 },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Current Skills */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-base">{t("Current Skills", "المهارات الحالية")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {currentSkills.map((skill) => (
                <div key={skill.name}>
                  <div className="mb-1 flex items-center justify-between">
                    <span className="text-sm font-medium">{skill.name}</span>
                    <span className="text-sm font-medium text-primary">{skill.level}%</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-muted">
                    <div className="h-full rounded-full bg-primary" style={{ width: `${skill.level}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Required Skills */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-base">{t("Required Skills", "المهارات المطلوبة")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {requiredSkills.map((skill) => (
                <div key={skill.name}>
                  <div className="mb-1 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">{skill.name}</span>
                      <span
                        className={`rounded px-1.5 py-0.5 text-xs ${
                          skill.priority === "high"
                            ? "bg-destructive/10 text-destructive"
                            : skill.priority === "medium"
                              ? "bg-accent/20 text-accent-foreground"
                              : "bg-primary/10 text-primary"
                        }`}
                      >
                        {skill.priority === "high" ? t("High", "عالي") : skill.priority === "medium" ? t("Medium", "متوسط") : t("Low", "منخفض")}
                      </span>
                    </div>
                    <span className="text-xs text-muted-foreground">{skill.level}</span>
                  </div>
                  <div className="relative h-2 overflow-hidden rounded-full bg-muted">
                    <div className="absolute h-full border-e-2 border-foreground/30" style={{ width: `${skill.required}%` }} />
                    <div
                      className={`h-full rounded-full ${
                        skill.priority === "high" ? "bg-destructive" : skill.priority === "medium" ? "bg-accent" : "bg-primary"
                      }`}
                      style={{ width: `${skill.current}%` }}
                    />
                  </div>
                  <div className="mt-1 flex justify-between text-xs text-muted-foreground">
                    <span>{t("Current", "الحالي")}: {skill.current}%</span>
                    <span>{t("Required", "المطلوب")}: {skill.required}%</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Gap Summary Table */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle className="text-base">{t("Gap Summary", "ملخص الفجوات")}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="pb-3 text-start font-medium text-muted-foreground">{t("Skill", "المهارة")}</th>
                  <th className="pb-3 text-start font-medium text-muted-foreground">{t("Current", "الحالي")}</th>
                  <th className="pb-3 text-start font-medium text-muted-foreground">{t("Required", "المطلوب")}</th>
                  <th className="pb-3 text-start font-medium text-muted-foreground">{t("Gap", "الفجوة")}</th>
                  <th className="pb-3 text-start font-medium text-muted-foreground">{t("Priority", "الأولوية")}</th>
                </tr>
              </thead>
              <tbody>
                {requiredSkills.map((skill) => (
                  <tr key={skill.name} className="border-b border-border/50">
                    <td className="py-3 font-medium">{skill.name}</td>
                    <td className="py-3">{skill.current}%</td>
                    <td className="py-3">{skill.required}%</td>
                    <td className="py-3 font-medium text-destructive">-{skill.required - skill.current}%</td>
                    <td className="py-3">
                      <span
                        className={`rounded px-2 py-1 text-xs ${
                          skill.priority === "high"
                            ? "bg-destructive/10 text-destructive"
                            : skill.priority === "medium"
                              ? "bg-accent/20 text-accent-foreground"
                              : "bg-primary/10 text-primary"
                        }`}
                      >
                        {skill.priority === "high" ? t("High", "عالي") : skill.priority === "medium" ? t("Medium", "متوسط") : t("Low", "منخفض")}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
