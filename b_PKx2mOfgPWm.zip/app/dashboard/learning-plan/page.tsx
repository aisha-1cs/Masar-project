"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, Circle, Clock } from "lucide-react";
import { useLanguage } from "@/lib/language-context";

export default function LearningPlanPage() {
  const { t } = useLanguage();

  const initialPlan = [
    { id: 1, skill: t("Machine Learning Basics", "أساسيات تعلم الآلة"), reason: t("Foundation for AI/ML career path", "أساس مسار الذكاء الاصطناعي"), duration: t("4 weeks", "4 أسابيع"), status: "completed" },
    { id: 2, skill: t("Python for Data Science", "بايثون لعلم البيانات"), reason: t("Essential programming skill for ML", "مهارة برمجة أساسية للتعلم الآلي"), duration: t("3 weeks", "3 أسابيع"), status: "completed" },
    { id: 3, skill: t("TensorFlow Fundamentals", "أساسيات تنسرفلو"), reason: t("Most used ML framework in industry", "إطار العمل الأكثر استخداماً"), duration: t("5 weeks", "5 أسابيع"), status: "in-progress" },
    { id: 4, skill: t("Docker Containerization", "حاويات دوكر"), reason: t("Required for ML deployment", "مطلوب لنشر النماذج"), duration: t("2 weeks", "أسبوعين"), status: "pending" },
    { id: 5, skill: t("AWS Machine Learning", "تعلم آلي على أمازون"), reason: t("Cloud deployment skills", "مهارات النشر السحابي"), duration: t("4 weeks", "4 أسابيع"), status: "pending" },
    { id: 6, skill: t("MLOps Best Practices", "أفضل ممارسات MLOps"), reason: t("Production ML systems", "أنظمة الإنتاج"), duration: t("3 weeks", "3 أسابيع"), status: "pending" },
  ];

  const [plan, setPlan] = useState(initialPlan);

  const markComplete = (id: number) => {
    setPlan(plan.map((item) => (item.id === id ? { ...item, status: "completed" } : item)));
  };

  const startItem = (id: number) => {
    setPlan(plan.map((item) => (item.id === id ? { ...item, status: "in-progress" } : item)));
  };

  const completedCount = plan.filter((item) => item.status === "completed").length;
  const totalCount = plan.length;
  const progressPercent = Math.round((completedCount / totalCount) * 100);

  return (
    <div className="space-y-6">
      {/* Progress Overview */}
      <Card className="border-border">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">{t("Overall Progress", "التقدم الإجمالي")}</p>
              <p className="text-2xl font-bold">
                {completedCount} / {totalCount} {t("completed", "مكتمل")}
              </p>
            </div>
            <div className="text-end">
              <p className="text-3xl font-bold text-primary">{progressPercent}%</p>
            </div>
          </div>
          <div className="mt-4 h-3 overflow-hidden rounded-full bg-muted">
            <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${progressPercent}%` }} />
          </div>
        </CardContent>
      </Card>

      {/* Learning Roadmap */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle className="text-base">{t("Your Roadmap", "خريطة التعلم")}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {plan.map((item, index) => (
              <div
                key={item.id}
                className={`relative rounded-lg border p-4 ${
                  item.status === "completed"
                    ? "border-primary/30 bg-primary/5"
                    : item.status === "in-progress"
                      ? "border-accent bg-accent/5"
                      : "border-border"
                }`}
              >
                {index < plan.length - 1 && (
                  <div className="absolute -bottom-4 start-6 h-4 w-0.5 bg-border" />
                )}

                <div className="flex items-start gap-4">
                  <div
                    className={`flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full ${
                      item.status === "completed"
                        ? "bg-primary text-primary-foreground"
                        : item.status === "in-progress"
                          ? "bg-accent text-accent-foreground"
                          : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {item.status === "completed" ? <Check className="h-4 w-4" /> : <Circle className="h-4 w-4" />}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <h3 className="font-medium text-foreground">{item.skill}</h3>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Clock className="h-4 w-4" />
                        {item.duration}
                      </div>
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">
                      <span className="font-medium">{t("Why", "لماذا")}: </span>
                      {item.reason}
                    </p>

                    <div className="mt-3 flex gap-2">
                      {item.status === "pending" && (
                        <Button size="sm" onClick={() => startItem(item.id)}>
                          {t("Start", "ابدأ")}
                        </Button>
                      )}
                      {item.status === "in-progress" && (
                        <Button size="sm" onClick={() => markComplete(item.id)}>
                          {t("Mark as Complete", "تحديد كمكتمل")}
                        </Button>
                      )}
                      {item.status === "completed" && (
                        <span className="text-sm text-primary">{t("Completed", "مكتمل")}</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
