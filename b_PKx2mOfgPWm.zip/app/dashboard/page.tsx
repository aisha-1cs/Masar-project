"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, Play } from "lucide-react";
import { useLanguage } from "@/lib/language-context";

export default function DashboardPage() {
  const { t } = useLanguage();

  const currentSkills = [
    "Python",
    "SQL",
    "React",
    "UI/UX",
    "JavaScript",
    t("Data Analysis", "تحليل البيانات"),
  ];

  const skillGaps = [
    { name: t("Machine Learning", "تعلم الآلة"), progress: 65, priority: "high" },
    { name: t("Docker", "دوكر"), progress: 40, priority: "medium" },
    { name: t("AWS", "خدمات أمازون"), progress: 25, priority: "low" },
  ];

  const recommendedCourses = [
    {
      title: t("Machine Learning Fundamentals", "أساسيات تعلم الآلة"),
      provider: "Coursera",
      duration: t("8 weeks", "8 أسابيع"),
    },
    {
      title: t("Docker for Developers", "دوكر للمطورين"),
      provider: "SDA",
      duration: t("4 weeks", "4 أسابيع"),
    },
    {
      title: t("AWS Cloud Practitioner", "ممارس AWS السحابي"),
      provider: "Tuwaiq",
      duration: t("6 weeks", "6 أسابيع"),
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Row - Stats */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Career Readiness */}
        <Card className="border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {t("Career Readiness", "جاهزية المسار المهني")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center py-2">
              <div className="relative h-24 w-24">
                <svg className="h-full w-full -rotate-90">
                  <circle cx="48" cy="48" r="40" fill="none" stroke="currentColor" strokeWidth="6" className="text-muted" />
                  <circle cx="48" cy="48" r="40" fill="none" stroke="currentColor" strokeWidth="6" strokeLinecap="round" strokeDasharray={`${78 * 2.51} 251`} className="text-primary" />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-bold">78%</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {t("Current Skills", "المهارات الحالية")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-foreground">12</p>
            <p className="text-sm text-muted-foreground">{t("skills identified", "مهارة محددة")}</p>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {t("Skill Gaps", "الفجوات")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-foreground">5</p>
            <p className="text-sm text-muted-foreground">{t("areas to improve", "مجالات للتحسين")}</p>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {t("Recommended Courses", "الدورات الموصى بها")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-foreground">8</p>
            <p className="text-sm text-muted-foreground">{t("courses available", "دورة متاحة")}</p>
          </CardContent>
        </Card>
      </div>

      {/* Middle Row */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Current Skills */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-base">{t("Current Skills", "المهارات الحالية")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {currentSkills.map((skill) => (
                <span key={skill} className="rounded-md border border-border bg-muted/50 px-3 py-1.5 text-sm">
                  {skill}
                </span>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Skill Gaps */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-base">{t("Skill Gaps", "الفجوات المهارية")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {skillGaps.map((skill) => (
                <div key={skill.name}>
                  <div className="mb-1 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">{skill.name}</span>
                      <span
                        className={`rounded px-1.5 py-0.5 text-xs ${
                          skill.priority === "high"
                            ? "bg-destructive/10 text-destructive"
                            : skill.priority === "medium"
                              ? "bg-accent/20 text-accent-foreground"
                              : "bg-primary/10 text-primary"
                        }`}
                      >
                        {skill.priority === "high"
                          ? t("High", "عالي")
                          : skill.priority === "medium"
                            ? t("Medium", "متوسط")
                            : t("Low", "منخفض")}
                      </span>
                    </div>
                    <span className="text-sm text-muted-foreground">{skill.progress}%</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-muted">
                    <div
                      className={`h-full rounded-full ${
                        skill.priority === "high"
                          ? "bg-destructive"
                          : skill.priority === "medium"
                            ? "bg-accent"
                            : "bg-primary"
                      }`}
                      style={{ width: `${skill.progress}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Recommended Courses */}
        <Card className="border-border lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">{t("Recommended Courses", "الدورات الموصى بها")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-3">
              {recommendedCourses.map((course) => (
                <div key={course.title} className="rounded-lg border border-border p-4">
                  <h4 className="mb-2 text-sm font-medium">{course.title}</h4>
                  <div className="mb-3 flex items-center gap-2 text-xs text-muted-foreground">
                    <span className="rounded bg-primary/10 px-2 py-0.5 font-medium text-primary">
                      {course.provider}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {course.duration}
                    </span>
                  </div>
                  <Button size="sm" className="w-full">
                    <Play className="me-1 h-3 w-3" />
                    {t("Start", "ابدأ")}
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Learning Progress */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-base">{t("Learning Progress", "التقدم في التعلم")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="mb-1 flex justify-between text-sm">
                  <span className="text-muted-foreground">{t("Overall", "الإجمالي")}</span>
                  <span className="font-medium">62%</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-muted">
                  <div className="h-full rounded-full bg-primary" style={{ width: "62%" }} />
                </div>
              </div>
              <div>
                <div className="mb-1 flex justify-between text-sm">
                  <span className="text-muted-foreground">{t("This Week", "هذا الأسبوع")}</span>
                  <span className="font-medium">{t("8h 30m", "8س 30د")}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-muted">
                  <div className="h-full rounded-full bg-accent" style={{ width: "70%" }} />
                </div>
              </div>
              <div className="border-t border-border pt-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">{t("Streak", "سلسلة التعلم")}</span>
                  <span className="text-2xl font-bold">{t("7 days", "7 أيام")}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
