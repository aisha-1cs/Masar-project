"use client";

import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send, User, Bot } from "lucide-react";
import { useLanguage } from "@/lib/language-context";

interface Message {
  id: number;
  role: "user" | "assistant";
  content: string;
}

export default function AssistantPage() {
  const { t, isRTL } = useLanguage();

  const suggestedQuestions = [
    t("What should I learn next?", "ماذا يجب أن أتعلم بعد ذلك؟"),
    t("Review my CV", "راجع سيرتي الذاتية"),
    t("How can I improve my skills?", "كيف يمكنني تحسين مهاراتي؟"),
    t("What jobs match my profile?", "ما الوظائف المناسبة لملفي؟"),
  ];

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      role: "assistant",
      content: t(
        "Hello! I am your career assistant. How can I help you today?",
        "مرحباً! أنا مساعدك المهني. كيف يمكنني مساعدتك اليوم؟"
      ),
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const sendMessage = async (content: string) => {
    if (!content.trim()) return;

    const userMessage: Message = { id: messages.length + 1, role: "user", content };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    await new Promise((resolve) => setTimeout(resolve, 1500));

    const assistantMessage: Message = {
      id: messages.length + 2,
      role: "assistant",
      content: t(
        "I understand your question. Based on your profile and learning progress, I can provide personalized recommendations. Your current focus should be on completing the TensorFlow Fundamentals course to strengthen your ML skills.",
        "أفهم سؤالك. بناءً على ملفك الشخصي وتقدمك في التعلم، يمكنني تقديم توصيات مخصصة. يجب أن يكون تركيزك الحالي على إكمال دورة أساسيات تنسرفلو لتعزيز مهاراتك في تعلم الآلة."
      ),
    };

    setMessages((prev) => [...prev, assistantMessage]);
    setIsLoading(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(input);
  };

  return (
    <div className="flex h-[calc(100vh-8rem)] flex-col">
      <Card className="flex flex-1 flex-col overflow-hidden border-border">
        {/* Messages */}
        <CardContent className="flex-1 overflow-y-auto p-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.role === "user" ? "flex-row-reverse" : ""}`}
              >
                <div
                  className={`flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full ${
                    message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                  }`}
                >
                  {message.role === "user" ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                </div>
                <div
                  className={`max-w-[80%] rounded-lg px-4 py-3 ${
                    message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                  }`}
                >
                  <p className="whitespace-pre-wrap text-sm">{message.content}</p>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted text-muted-foreground">
                  <Bot className="h-4 w-4" />
                </div>
                <div className="rounded-lg bg-muted px-4 py-3">
                  <div className="flex gap-1">
                    <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground" />
                    <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground [animation-delay:0.1s]" />
                    <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground [animation-delay:0.2s]" />
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardContent>

        {/* Suggested Questions */}
        {messages.length === 1 && (
          <div className="border-t border-border p-4">
            <p className="mb-2 text-sm text-muted-foreground">{t("Suggested questions:", "أسئلة مقترحة:")}</p>
            <div className="flex flex-wrap gap-2">
              {suggestedQuestions.map((q, i) => (
                <Button key={i} variant="outline" size="sm" onClick={() => sendMessage(q)} className="text-xs">
                  {q}
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Input */}
        <div className="border-t border-border p-4">
          <form onSubmit={handleSubmit} className="flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={t("Type your message", "اكتب رسالتك")}
              disabled={isLoading}
              className="flex-1"
            />
            <Button type="submit" disabled={isLoading || !input.trim()}>
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      </Card>
    </div>
  );
}
