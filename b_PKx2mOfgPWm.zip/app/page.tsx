"use client";

import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Navbar } from "@/components/navbar";
import { useLanguage } from "@/lib/language-context";
import { FileText, Target, BookOpen, ChevronLeft, ChevronRight } from "lucide-react";

export default function HomePage() {
  const { t, isRTL } = useLanguage();
  const Arrow = isRTL ? ChevronLeft : ChevronRight;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative overflow-hidden border-b border-border py-20 lg:py-32">
        {/* Purple accent background */}
        <div className="absolute inset-0 bg-gradient-to-b from-purple-50/80 via-background to-background" />
        <div className="absolute -top-24 start-1/2 h-96 w-96 -translate-x-1/2 rounded-full bg-purple-100/50 blur-3xl" />
        
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center text-center">
            {/* Large Centered Logo */}
            <div className="mb-10">
              <Image
                src="/logo.jpeg"
                alt="Masar Logo"
                width={320}
                height={128}
                className="h-28 w-auto sm:h-36 lg:h-44"
                priority
              />
            </div>

            {/* Headline */}
            <h1 className="max-w-3xl text-balance text-3xl font-semibold text-foreground sm:text-4xl lg:text-5xl">
              {t(
                "Analyze your skills and build your career path",
                "حلل مهاراتك وابنِ مسارك المهني"
              )}
            </h1>

            <p className="mt-5 max-w-2xl text-pretty text-lg text-muted-foreground">
              {t(
                "Discover your skill gaps and get a personalized learning plan aligned with market requirements",
                "اكتشف الفجوة المهارية واحصل على خطة تعلم مخصصة تتوافق مع متطلبات سوق العمل"
              )}
            </p>

            {/* CTA Button */}
            <div className="mt-10">
              <Link href="/onboarding">
                <Button size="lg" className="min-w-[200px] bg-purple-600 hover:bg-purple-700">
                  {t("Start Now", "ابدأ الآن")}
                  <Arrow className="ms-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-center text-2xl font-semibold text-foreground">
            {t("How it works", "كيف يعمل")}
          </h2>
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {[
              {
                step: "1",
                icon: FileText,
                title: t("Enter Your Information", "أدخل بياناتك"),
                desc: t(
                  "Tell us about your education, skills, and career goals",
                  "أخبرنا عن تعليمك ومهاراتك وأهدافك المهنية"
                ),
              },
              {
                step: "2",
                icon: Target,
                title: t("Skills Analysis", "تحليل المهارات"),
                desc: t(
                  "We analyze your profile against market requirements",
                  "نحلل ملفك الشخصي مقابل متطلبات السوق"
                ),
              },
              {
                step: "3",
                icon: BookOpen,
                title: t("Get Your Roadmap", "احصل على خطتك"),
                desc: t(
                  "Receive a personalized learning plan with recommended courses",
                  "احصل على خطة تعلم مخصصة مع دورات موصى بها"
                ),
              },
            ].map((item) => (
              <div
                key={item.step}
                className="rounded-lg border border-border bg-card p-6 text-center"
              >
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <item.icon className="h-6 w-6 text-primary" />
                </div>
                <div className="mx-auto mt-2 flex h-6 w-6 items-center justify-center rounded-full bg-muted text-xs font-medium text-muted-foreground">
                  {item.step}
                </div>
                <h3 className="mt-4 text-lg font-medium text-foreground">
                  {item.title}
                </h3>
                <p className="mt-2 text-sm text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="border-t border-border bg-muted/30 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-center text-2xl font-semibold text-foreground">
            {t("Features", "المميزات")}
          </h2>
          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { title: t("Skill Gap Analysis", "تحليل الفجوة المهارية") },
              { title: t("Personalized Learning Plan", "خطة تعلم مخصصة") },
              { title: t("Course Recommendations", "توصيات بالدورات") },
              { title: t("Career Assistant", "مساعد مهني") },
            ].map((feature) => (
              <div
                key={feature.title}
                className="rounded-lg border border-border bg-card p-4"
              >
                <div className="mb-3 h-2 w-8 rounded bg-accent" />
                <h3 className="font-medium text-foreground">{feature.title}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="mx-auto max-w-3xl px-4 text-center sm:px-6 lg:px-8">
          <h2 className="text-2xl font-semibold text-foreground">
            {t("Ready to start your journey?", "هل أنت مستعد لبدء رحلتك؟")}
          </h2>
          <div className="mt-6">
            <Link href="/onboarding">
              <Button size="lg" className="min-w-[180px]">
                {t("Start Now", "ابدأ الآن")}
                <Arrow className="ms-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card py-8">
        <div className="mx-auto max-w-7xl px-4 text-center text-sm text-muted-foreground sm:px-6 lg:px-8">
          <p>
            {t(
              "2024 Masar. All rights reserved.",
              "2024 مسار. جميع الحقوق محفوظة."
            )}
          </p>
        </div>
      </footer>
    </div>
  );
}
