"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Navbar } from "@/components/navbar";
import { useLanguage } from "@/lib/language-context";
import { Upload, Check, ChevronLeft, ChevronRight } from "lucide-react";

export default function OnboardingPage() {
  const router = useRouter();
  const { t, isRTL } = useLanguage();
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [cvFile, setCvFile] = useState<File | null>(null);

  const [formData, setFormData] = useState({
    major: "",
    university: "",
    academicYear: "",
    currentSkills: "",
    courses: "",
    certificates: "",
    languages: "",
    targetJob: "",
    weeklyHours: "",
  });

  const steps = [
    { id: 1, title: t("Basic Info", "المعلومات الأساسية") },
    { id: 2, title: t("Skills", "المهارات") },
    { id: 3, title: t("Career Goal", "الهدف المهني") },
    { id: 4, title: t("Upload CV", "رفع السيرة الذاتية") },
  ];

  const handleNext = () => {
    if (currentStep < 4) setCurrentStep(currentStep + 1);
  };

  const handleBack = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1500));
    router.push("/analysis");
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) setCvFile(e.target.files[0]);
  };

  const BackIcon = isRTL ? ChevronRight : ChevronLeft;
  const NextIcon = isRTL ? ChevronLeft : ChevronRight;

  return (
    <div className="min-h-screen bg-muted/30">
      <Navbar showAuth={false} />

      <main className="mx-auto max-w-2xl px-4 py-12 sm:px-6 lg:px-8">
        {/* Step Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => (
              <div key={step.id} className="flex flex-1 items-center">
                <div className="flex flex-col items-center">
                  <div
                    className={`flex h-10 w-10 items-center justify-center rounded-full border-2 text-sm font-medium transition-colors ${
                      currentStep > step.id
                        ? "border-primary bg-primary text-primary-foreground"
                        : currentStep === step.id
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border bg-card text-muted-foreground"
                    }`}
                  >
                    {currentStep > step.id ? <Check className="h-5 w-5" /> : step.id}
                  </div>
                  <p
                    className={`mt-2 text-xs font-medium ${
                      currentStep >= step.id ? "text-foreground" : "text-muted-foreground"
                    }`}
                  >
                    {step.title}
                  </p>
                </div>
                {index < steps.length - 1 && (
                  <div
                    className={`mx-2 h-0.5 flex-1 ${
                      currentStep > step.id ? "bg-primary" : "bg-border"
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Form Card */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-center text-xl">
              {steps[currentStep - 1].title}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {/* Step 1: Basic Info */}
            {currentStep === 1 && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="major">{t("Major", "التخصص")}</Label>
                  <Input
                    id="major"
                    placeholder={t("e.g. Computer Science", "مثال: علوم الحاسب")}
                    value={formData.major}
                    onChange={(e) => setFormData({ ...formData, major: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="university">{t("University", "الجامعة")}</Label>
                  <Input
                    id="university"
                    placeholder={t("e.g. King Saud University", "مثال: جامعة الملك سعود")}
                    value={formData.university}
                    onChange={(e) => setFormData({ ...formData, university: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="academicYear">{t("Academic Year", "السنة الدراسية")}</Label>
                  <Select
                    value={formData.academicYear}
                    onValueChange={(value) => setFormData({ ...formData, academicYear: value })}
                  >
                    <SelectTrigger id="academicYear">
                      <SelectValue placeholder={t("Select year", "اختر السنة")} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">{t("First Year", "السنة الأولى")}</SelectItem>
                      <SelectItem value="2">{t("Second Year", "السنة الثانية")}</SelectItem>
                      <SelectItem value="3">{t("Third Year", "السنة الثالثة")}</SelectItem>
                      <SelectItem value="4">{t("Fourth Year", "السنة الرابعة")}</SelectItem>
                      <SelectItem value="graduate">{t("Graduate", "خريج")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {/* Step 2: Skills */}
            {currentStep === 2 && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="currentSkills">{t("Current Skills", "المهارات الحالية")}</Label>
                  <Textarea
                    id="currentSkills"
                    placeholder={t("e.g. Python, JavaScript, SQL...", "مثال: بايثون، جافاسكريبت، SQL...")}
                    value={formData.currentSkills}
                    onChange={(e) => setFormData({ ...formData, currentSkills: e.target.value })}
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="courses">{t("Completed Courses", "الدورات المكتملة")}</Label>
                  <Textarea
                    id="courses"
                    placeholder={t("e.g. Data Science Fundamentals...", "مثال: أساسيات علم البيانات...")}
                    value={formData.courses}
                    onChange={(e) => setFormData({ ...formData, courses: e.target.value })}
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="certificates">{t("Certificates", "الشهادات")}</Label>
                  <Input
                    id="certificates"
                    placeholder={t("e.g. AWS Certified...", "مثال: شهادة AWS...")}
                    value={formData.certificates}
                    onChange={(e) => setFormData({ ...formData, certificates: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="languages">{t("Languages", "اللغات")}</Label>
                  <Input
                    id="languages"
                    placeholder={t("e.g. Arabic, English...", "مثال: العربية، الإنجليزية...")}
                    value={formData.languages}
                    onChange={(e) => setFormData({ ...formData, languages: e.target.value })}
                  />
                </div>
              </div>
            )}

            {/* Step 3: Career Goal */}
            {currentStep === 3 && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="targetJob">{t("Target Job", "الوظيفة المستهدفة")}</Label>
                  <Select
                    value={formData.targetJob}
                    onValueChange={(value) => setFormData({ ...formData, targetJob: value })}
                  >
                    <SelectTrigger id="targetJob">
                      <SelectValue placeholder={t("Select career path", "اختر المسار")} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="data-analyst">{t("Data Analyst", "محلل بيانات")}</SelectItem>
                      <SelectItem value="software-engineer">{t("Software Engineer", "مهندس برمجيات")}</SelectItem>
                      <SelectItem value="product-manager">{t("Product Manager", "مدير منتجات")}</SelectItem>
                      <SelectItem value="ux-designer">{t("UX Designer", "مصمم تجربة المستخدم")}</SelectItem>
                      <SelectItem value="cybersecurity">{t("Cybersecurity Specialist", "أخصائي أمن سيبراني")}</SelectItem>
                      <SelectItem value="ai-ml">{t("AI/ML Engineer", "مهندس ذكاء اصطناعي")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="weeklyHours">{t("Weekly Learning Hours (Optional)", "ساعات التعلم الأسبوعية (اختياري)")}</Label>
                  <Select
                    value={formData.weeklyHours}
                    onValueChange={(value) => setFormData({ ...formData, weeklyHours: value })}
                  >
                    <SelectTrigger id="weeklyHours">
                      <SelectValue placeholder={t("Select hours", "اختر الساعات")} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">{t("5 hours", "5 ساعات")}</SelectItem>
                      <SelectItem value="10">{t("10 hours", "10 ساعات")}</SelectItem>
                      <SelectItem value="15">{t("15 hours", "15 ساعة")}</SelectItem>
                      <SelectItem value="20">{t("20+ hours", "20+ ساعة")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {/* Step 4: Upload CV */}
            {currentStep === 4 && (
              <div className="space-y-4">
                <div
                  className={`flex flex-col items-center justify-center rounded-lg border-2 border-dashed p-8 transition-colors ${
                    cvFile ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
                  }`}
                >
                  <input
                    type="file"
                    id="cv-upload"
                    accept=".pdf,.doc,.docx"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  <label htmlFor="cv-upload" className="flex cursor-pointer flex-col items-center">
                    {cvFile ? (
                      <>
                        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
                          <Check className="h-7 w-7 text-primary" />
                        </div>
                        <p className="mt-4 font-medium text-foreground">{cvFile.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {t("Click to change file", "انقر لتغيير الملف")}
                        </p>
                      </>
                    ) : (
                      <>
                        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-muted">
                          <Upload className="h-7 w-7 text-muted-foreground" />
                        </div>
                        <p className="mt-4 font-medium text-foreground">
                          {t("Upload your CV", "رفع السيرة الذاتية")}
                        </p>
                        <p className="mt-2 text-xs text-muted-foreground">PDF, DOC, DOCX (Max 10MB)</p>
                      </>
                    )}
                  </label>
                </div>
                <p className="text-center text-sm text-muted-foreground">
                  {t(
                    "Your CV will be analyzed to provide better recommendations",
                    "سيتم تحليل سيرتك الذاتية لتقديم توصيات أفضل"
                  )}
                </p>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="mt-8 flex justify-between">
              <Button variant="outline" onClick={handleBack} disabled={currentStep === 1}>
                <BackIcon className="me-1 h-4 w-4" />
                {t("Back", "رجوع")}
              </Button>
              {currentStep < 4 ? (
                <Button onClick={handleNext}>
                  {t("Next", "التالي")}
                  <NextIcon className="ms-1 h-4 w-4" />
                </Button>
              ) : (
                <Button onClick={handleSubmit} disabled={isLoading}>
                  {isLoading ? t("Processing...", "جاري المعالجة...") : t("Submit", "إرسال")}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
