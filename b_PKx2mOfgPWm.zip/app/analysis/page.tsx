"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { Check, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Navbar } from "@/components/navbar";
import { useLanguage } from "@/lib/language-context";

export default function AnalysisPage() {
  const router = useRouter();
  const { t } = useLanguage();
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(0);

  const analysisSteps = [
    { id: 1, title: t("Extracting skills from your profile", "استخراج المهارات من ملفك") },
    { id: 2, title: t("Matching with job market requirements", "مطابقة متطلبات سوق العمل") },
    { id: 3, title: t("Identifying skill gaps", "تحديد الفجوة المهارية") },
    { id: 4, title: t("Generating your learning plan", "إنشاء خطة التعلم") },
  ];

  useEffect(() => {
    const stepInterval = setInterval(() => {
      setCurrentStep((prev) => {
        if (prev >= analysisSteps.length) {
          clearInterval(stepInterval);
          setTimeout(() => router.push("/dashboard"), 800);
          return prev;
        }
        return prev + 1;
      });
    }, 1200);

    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 2;
      });
    }, 80);

    return () => {
      clearInterval(stepInterval);
      clearInterval(progressInterval);
    };
  }, [router, analysisSteps.length]);

  return (
    <div className="min-h-screen bg-muted/30">
      <Navbar showAuth={false} />

      <main className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 py-12">
        <div className="w-full max-w-lg">
          <Card className="border-border">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4">
                <Image
                  src="/logo.jpeg"
                  alt="Masar Logo"
                  width={100}
                  height={40}
                  className="h-10 w-auto"
                />
              </div>
              <CardTitle className="text-xl">
                {t("Analyzing your data", "جاري تحليل بياناتك")}
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                {t("Please wait", "يرجى الانتظار")}
              </p>
            </CardHeader>
            <CardContent>
              {/* Steps */}
              <div className="space-y-3">
                {analysisSteps.map((step, index) => {
                  const isCompleted = currentStep > index;
                  const isActive = currentStep === index;

                  return (
                    <div
                      key={step.id}
                      className={`flex items-center gap-3 rounded-lg border p-3 transition-colors ${
                        isCompleted
                          ? "border-primary/30 bg-primary/5"
                          : isActive
                            ? "border-primary bg-card"
                            : "border-border bg-muted/30"
                      }`}
                    >
                      <div
                        className={`flex h-8 w-8 items-center justify-center rounded-full ${
                          isCompleted
                            ? "bg-primary text-primary-foreground"
                            : isActive
                              ? "bg-primary/20 text-primary"
                              : "bg-muted text-muted-foreground"
                        }`}
                      >
                        {isCompleted ? (
                          <Check className="h-4 w-4" />
                        ) : isActive ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <span className="text-xs">{step.id}</span>
                        )}
                      </div>
                      <p
                        className={`flex-1 text-sm ${isCompleted || isActive ? "text-foreground" : "text-muted-foreground"}`}
                      >
                        {step.title}
                      </p>
                    </div>
                  );
                })}
              </div>

              {/* Progress Bar */}
              <div className="mt-6 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{t("Progress", "التقدم")}</span>
                  <span className="font-medium text-foreground">{progress}%</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-muted">
                  <div
                    className="h-full rounded-full bg-primary transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
