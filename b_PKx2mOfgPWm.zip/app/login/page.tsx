"use client";

import { useState, Suspense } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Navbar } from "@/components/navbar";
import { useLanguage } from "@/lib/language-context";

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const defaultTab = searchParams.get("tab") === "signup" ? "signup" : "login";
  const { t } = useLanguage();

  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    router.push("/dashboard");
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    router.push("/onboarding");
  };

  return (
    <Card className="w-full max-w-md border-border">
      <CardHeader className="pb-4 text-center">
        <Link href="/" className="mx-auto mb-4 block">
          <Image
            src="/logo.jpeg"
            alt="Masar Logo"
            width={120}
            height={48}
            className="h-12 w-auto"
          />
        </Link>
        <h1 className="text-xl font-semibold text-foreground">
          {t("Welcome to Masar", "مرحباً بك في مسار")}
        </h1>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue={defaultTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="login">{t("Login", "تسجيل الدخول")}</TabsTrigger>
            <TabsTrigger value="signup">{t("Sign up", "إنشاء حساب")}</TabsTrigger>
          </TabsList>

          <TabsContent value="login" className="mt-6">
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="login-email">{t("Email", "البريد الإلكتروني")}</Label>
                <Input
                  id="login-email"
                  type="email"
                  placeholder="email@example.com"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="login-password">{t("Password", "كلمة المرور")}</Label>
                <Input
                  id="login-password"
                  type="password"
                  placeholder="••••••••"
                  required
                />
              </div>
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? t("Loading...", "جاري التحميل...") : t("Login", "تسجيل الدخول")}
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="signup" className="mt-6">
            <form onSubmit={handleSignup} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="signup-email">{t("Email", "البريد الإلكتروني")}</Label>
                <Input
                  id="signup-email"
                  type="email"
                  placeholder="email@example.com"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="signup-password">{t("Password", "كلمة المرور")}</Label>
                <Input
                  id="signup-password"
                  type="password"
                  placeholder="••••••••"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="user-type">{t("User Type", "نوع المستخدم")}</Label>
                <Select required>
                  <SelectTrigger id="user-type">
                    <SelectValue placeholder={t("Select type", "اختر النوع")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="student">{t("Student", "طالب")}</SelectItem>
                    <SelectItem value="graduate">{t("Graduate", "حديث تخرج")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? t("Loading...", "جاري التحميل...") : t("Sign up", "إنشاء حساب")}
              </Button>
            </form>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

export default function LoginPage() {
  return (
    <div className="flex min-h-screen flex-col bg-muted/30">
      <Navbar showAuth={false} />
      <main className="flex flex-1 items-center justify-center px-4 py-12">
        <Suspense fallback={<div className="h-96 w-full max-w-md animate-pulse rounded-lg bg-muted" />}>
          <LoginForm />
        </Suspense>
      </main>
      <footer className="border-t border-border bg-card py-6">
        <div className="mx-auto max-w-7xl px-4 text-center text-sm text-muted-foreground">
          <p>2024 Masar - مسار</p>
        </div>
      </footer>
    </div>
  );
}
