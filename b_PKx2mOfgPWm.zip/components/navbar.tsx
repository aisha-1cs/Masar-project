"use client";

import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/lib/language-context";

interface NavbarProps {
  showAuth?: boolean;
}

export function Navbar({ showAuth = true }: NavbarProps) {
  const { language, setLanguage, t } = useLanguage();

  return (
    <header className="border-b border-border bg-card">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Logo */}
        <Link href="/" className="flex items-center">
          <Image
            src="/logo.jpeg"
            alt="Masar Logo"
            width={100}
            height={32}
            className="h-8 w-auto"
          />
        </Link>

        {/* Right Side */}
        <div className="flex items-center gap-4">
          {/* Language Switcher */}
          <div className="flex items-center rounded-md border border-border bg-muted/50">
            <button
              onClick={() => setLanguage("ar")}
              className={`px-3 py-1.5 text-sm font-medium transition-colors ${
                language === "ar"
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              } rounded-l-md`}
            >
              AR
            </button>
            <button
              onClick={() => setLanguage("en")}
              className={`px-3 py-1.5 text-sm font-medium transition-colors ${
                language === "en"
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              } rounded-r-md`}
            >
              EN
            </button>
          </div>

          {/* Auth Buttons */}
          {showAuth && (
            <div className="flex items-center gap-2">
              <Link href="/login">
                <Button variant="ghost" size="sm">
                  {t("Login", "تسجيل الدخول")}
                </Button>
              </Link>
              <Link href="/login?tab=signup">
                <Button size="sm">{t("Sign up", "إنشاء حساب")}</Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
